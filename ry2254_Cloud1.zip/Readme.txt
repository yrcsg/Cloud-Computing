Readme for TwitTube:
Ruichi Yu ry2254, Shuguan Yang sy2518

Our application implements following functions:
1. We have a web app build on RDS and S3, which can let people start conversation based on broadcasting videos. 
2. We use SNS, every time a new video has been uploaded, users who have subscribed this topic will get a notification.
3. We use cloudfront to distribute the videos. 
4. We use Github to share the code.