package com.database;

public class DBManager_test {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		DBManager test=new DBManager();
		test.readDataBase();
	}

}
